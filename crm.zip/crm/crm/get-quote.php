<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();
error_reporting(0);
/*if(isset($_POST['submit']))
{
    $uid=$_SESSION['id'];
	$name=$_POST['name'];
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$company=$_POST['company'];
	$service=$_POST['service'];
	$query=$_POST['query'];
	$pd=date('Y-m-d');
mysqli_query($con,"insert into prequest(user_id,service,name,email,contactno,company,status,query,posting_date) values('$uid','$service','$name','$email','$contact','$company','0','$query','$pd')");
$_SESSION['msg']="Query Send";
}*/
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>CRM | Request Quote</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="admin/assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="admin/assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
    <script>
        function changeAmount(val){
             
            document.getElementById('formamt').value = val;

            document.getElementById('displayAmt').innerText = val;
        }
    </script>
<?php include("header.php");?>
<div class="page-container row-fluid">
	<?php include("leftbar.php");?>
	<div class="clearfix"></div>
    <!-- END SIDEBAR MENU --> 
  </div>
  </div>
  <a href="#" class="scrollup">Scroll</a>
   <div class="footer-widget">		
	<div class="progress transparent progress-small no-radius no-margin">
		<div data-percentage="79%" class="progress-bar progress-bar-success animate-progress-bar" ></div>		
	</div>
	<div class="pull-right">
	</div>
  </div>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content"> 
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div id="portlet-config" class="modal hide">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button"></button>
        <h3>Widget Settings</h3>
      </div>
      <div class="modal-body"> Widget settings form goes here </div>
    </div>
    <div class="clearfix"></div>
    <div class="content">  
		<div class="page-title">
        <a href="./dashboard.php" class="page-title"> <i class="icon-custom-left"></i>	
			<h3>Request a Quote</h3></a>
     
	
             <div class="row">
                        <div class="col-md-12">
                    
                            <form class="form-horizontal" method="post" action="payment/pay.php" enctype="multipart/form-data">
                            <div class="panel panel-default">
                             
                                 <p style="color:#F00;"><?php echo $_SESSION['msg'];?><?php echo $_SESSION['msg']="";?></p>
                                <div class="panel-body">
                                    <p>Please click below mention services of your interest to receive quotation for the same:</p>
                                </div>
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-6">
                                           
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Name </label>
                                                <div class="col-md-9">                                            
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                        <input type="text" name="name" class="form-control" required/>
                                                    </div>                                            
                                                
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-3 control-label">Contact no</label>
                                                <div class="col-md-9 col-xs-12">
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                        <input type="text" name="contact" class="form-control" maxlength="10" required/>
                                                    </div>            
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            <div class="form-group">
                                             <label class="col-md-3 control-label">Service Required :</label>
                                                <div class="col-md-9"> 
                                                    
                                                <?php
                                                $ret=mysqli_query($con,"select * from services");
                                                $cnt=1;
                                                while($row=mysqli_fetch_array($ret))
                                                {
                                                    ?>


                                             <label class="check">
                                             <input type="radio" id="amt" class="icheckbox" name="service" value="<?php echo $row['id'];?>" checked="checked" onchange="return changeAmount(<?php echo $row['amount']; ?>)"/> <?php echo $row['service'];?></label><br>
                                             
                                             <?php } ?>
                                <input type="hidden" id="formamt" name="amount" value="0"/>
                                             
                                                </div>
                                            </div>
                                            
                                          
                                            
                                        </div>
                                        
                                        <div class="col-md-6">
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-3 control-label">Email</label>
                                                <div class="col-md-9">
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                        <input type="email" name="email" class="form-control datepicker" value="" required>                                            
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            
                                               <div class="form-group">                                        
                                                <label class="col-md-3 control-label">Company</label>
                                                <div class="col-md-9">
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                        <input type="text" name="company" class="form-control datepicker" value="" required>                                            
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                       
                                            
                                           
                                            
                                        </div>
                                        <div style="margin-top:20px;" class="col-md-6">
                                         <div class="form-group">
                                                <label class="col-md-3 control-label">Query</label>
                                                <div class="col-md-9 col-xs-12">                                            
                                                    <textarea class="form-control" rows="5" name="query" required></textarea>
                                                </div>
                                            </div></div>
                                        
                                    </div>

                                </div>
                                <div class="panel-footer" style=" align-items:center; width:100%; position:relative;">
                                    <button class="btn btn-default" style="display:inline-block">Clear Form</button>  
                                    <div style="display:inline-block; position:absolute; right:130px; top:20px;font-weight:800"><span>₹ </span><span id="displayAmt"> 1000</span></div>                                    
                                    <input value="Submit" type="submit" name="submit" class="btn btn-primary pull-right">
                                </div>
                            </div>
                            </form>
                            
                        </div>
                    </div>            
                                    
                                    
                                   
                                   
                                    
                               
                                    
                                    
                                      
             
            	
		</div>
    </div>
  </div>
<!-- BEGIN CHAT --> 

 </div>
<script src="admin/assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/breakpoints.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="admin/assets/plugins/pace/pace.min.js" type="text/javascript"></script>  
<script src="admin/assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="admin/assets/js/core.js" type="text/javascript"></script> 
<script src="admin/assets/js/chat.js" type="text/javascript"></script> 
<script src="admin/assets/js/demo.js" type="text/javascript"></script> 

</body>
</html>
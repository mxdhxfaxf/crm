<?php
include("dbconnection.php");
$id=$_GET['id'];
	 $q="update ticket set status=0 where id='$id'";
	 mysqli_query($con, $q);
     header('location:manage-tickets.php')


?>
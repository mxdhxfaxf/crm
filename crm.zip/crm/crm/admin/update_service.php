
<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

$id=$_POST['id'];
$cat=$_POST['category'];
    $des=$_POST['description'];
    $amt=$_POST['amount'];
    $a=mysqli_query($con,"update services set service='$cat',description='$des',amount='$amt' where id='$id'");
    if($a)
    {
        header('location:add-service.php');
    }

    ?>
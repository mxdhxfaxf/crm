<?php

$keyId = 'rzp_test_FrZ63ksgkAqomA';
$keySecret = 'I9qUsSjNLL8evnHoTf80k9ui';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

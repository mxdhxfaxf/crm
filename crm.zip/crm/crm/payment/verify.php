<?php

require('config.php');
if(!isset($_SESSION))
{
session_start();
}
require('../razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $html = "<p>Your payment was successful</p>
             <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";


include('../dbconnection.php');
$uid=$_SESSION['id'];
$name=$_SESSION['sname'];
$email=$_SESSION['email'];
$contact=$_SESSION['contact'];
$company=$_SESSION['company'];
$service=$_SESSION['service'];
$query=$_SESSION['query'];
$amount=$_SESSION['amount'];
$date = date('Y/m/d h:i:s', time());
	

$pd=date('Y-m-d');
mysqli_query($con,"insert into prequest(user_id,service,name,email,contactno,company,status,query,posting_date) values('$uid','$service','$name','$email','$contact','$company','0','$query','$pd')");

$ret=mysqli_query($con,"SELECT id FROM  prequest where id=(SELECT LAST_INSERT_ID());");
$row=mysqli_fetch_array($ret);
$q_id=$row['service'];
$id=$_POST['razorpay_payment_id'];


mysqli_query($con,"insert into payment(id,quote_id,amount,date) values('$id','$q_id','$amount','$pd')");
$_SESSION['msg']="Query Send";
        header("location:../get-quote.php");
             
}
else
{
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";
}

echo $html;

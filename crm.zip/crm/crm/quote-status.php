<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();
error_reporting(0);
?>

<!DOCTYPE html>
<html>
<head>
<style>
    .pending{
        display:;
        background-color:red;
        padding:3px 10px;
        width:70px ;
        color:white;
        border-radius:10px; 
    }
    .ongoing{
        display:;
        background-color:yellow;
        padding:3px 10px;
        width:70px ;
        color:black;
        border-radius:10px;
    }
    .closed{
        display:block;
        background-color:green;
        padding:3px 10px;
        width:70px ;
        color:white;
        border-radius:10px;
    }
    </style>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>CRM | Request Quote</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="admin/assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="admin/assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="admin/assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<?php include("header.php");?>
<div class="page-container row-fluid">
	<?php include("leftbar.php");?>
	<div class="clearfix"></div>
    <!-- END SIDEBAR MENU --> 
  </div>
  </div>
  <?php
   if(isset($_POST['delete']))
   {
      $id=$_POST['id'];
      $q="delete from prequest where id='$id'";
      mysqli_query($con, $q);
   }
   ?>
  <a href="#" class="scrollup">Scroll</a>
   <div class="footer-widget">		
	<div class="progress transparent progress-small no-radius no-margin">
		<div data-percentage="79%" class="progress-bar progress-bar-success animate-progress-bar" ></div>		
	</div>
	<div class="pull-right">
	</div>
  </div>
  <!-- END SIDEBAR --> 
  <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content"> 
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div id="portlet-config" class="modal hide">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button"></button>
        <h3>Widget Settings</h3>
      </div>
      <div class="modal-body"> Widget settings form goes here </div>
    </div>
    <div class="clearfix"></div>
    <div class="content">  
		<div class="page-title">
    <a href="./dashboard.php" class="page-title"> <i class="icon-custom-left"></i>	
			<h3>Quote Status</h3></a>
     
	
            <div class="row-fluid">
        <div class="span12">
          <div class="grid simple ">
            <div class="grid-title">
              <h4>Table <span class="semi-bold">Styles</span></h4>
              <div class="tools"> <a href="javascript:;" class="collapse"></a> <a href="#grid-config" data-toggle="modal" class="config"></a> <a href="javascript:;" class="reload"></a> <a href="javascript:;" class="remove"></a> </div>
            </div>
            <div class="grid-body ">
              <table class="table table-hover table-condensed" id="example">
                <thead>
                  <tr>
                    <th style="width:1%">#</th>
                    <th style="width:10%">Name</th>
                    <th style="width:10%" data-hide="phone,tablet">Email</th>
                    <th style="width:10%">Date Created</th>
                    <th style="width:20%" data-hide="phone,tablet">Services Required</th>
                    <th style="width:20%" data-hide="phone,tablet">Admin Remark</th>
                    <th style="width:10%">Status</th>
                    <th style="width:10%">Action </th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                $uid=$_SESSION['id'];
                echo $uid;
                $ret=mysqli_query($con,"select s.service as service_req,p.* from services s,prequest p where p.service=s.id and user_id='$uid' order by id desc");
				$cnt=1;
				while($row=mysqli_fetch_array($ret))
				{?>
                  <tr >
                    <td class="v-align-middle"><?php echo $cnt;?></td>
                    <td class="v-align-middle"><?php echo $row['name'];?></td>
                    <td class="v-align-middle"><span class="muted"><?php echo $row['email'];?></span></td>
                    <td><span class="muted"><?php echo $row['posting_date'];?></span></td>
                    <td class="v-align-middle"><?php echo $row['service_req'];?></td>
                    <td class="v-align-middle"><?php echo $row['remark'];?></td>
                    <td class="v-align-middle"><?php if($row['status']==0) echo "<span class='pending'>Pending</span>"; elseif($row['status']==1) echo "<span class='ongoing'>Ongoing</span>"; else echo "<span class='closed'>Closed</span>"; ?></td>
                      <td><form method="post" action="#">
                                            <input type="hidden" value="<?php echo $row['id'];?>" name="id">
					                 <?php echo $row['status']==0 ?  '<input type="submit" name="delete" value="Delete" class="btn btn-danger" aria-expanded="false">' : ""; ?>
                                        </form></td>
                  </tr>
                 <?php $cnt=$cnt+1; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
     </div>
            




		</div>
    </div>
  </div>
<!-- BEGIN CHAT --> 

 </div>
<script src="admin/assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/breakpoints.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script> 
<script src="admin/assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="admin/assets/plugins/pace/pace.min.js" type="text/javascript"></script>  
<script src="admin/assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="admin/assets/js/core.js" type="text/javascript"></script> 
<script src="admin/assets/js/chat.js" type="text/javascript"></script> 
<script src="admin/assets/js/demo.js" type="text/javascript"></script> 

</body>
</html>